GE PDF Tools v3 — FIXED

The previous build had a page-number validation bug: the regular expressions were over-escaped, so valid page numbers such as 1 or 1,3-5 were rejected.

This build fixes that bug.

Test:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge.
3. Choose a PDF.
4. For Split/Delete/Extract, enter for example: 1 or 1,3-5.
5. Click the operation button.

It still uses PDF libraries from public CDNs, so keep internet access enabled while testing.
